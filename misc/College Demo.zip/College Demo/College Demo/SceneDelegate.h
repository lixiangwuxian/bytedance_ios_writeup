//
//  SceneDelegate.h
//  College Demo
//
//  Created by mashujun on 2022/7/18.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

